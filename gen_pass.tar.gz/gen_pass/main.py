import secrets

uppercase_letters = "QWERTYUIOPASDFGHJKLÇZXCVBNM"
lowercase_letters = uppercase_letters.lower()
digits = "1234567890"
symbols = "!@#|$%&*/?°}[]\<>:;"

upper, lower, nums, symbo = True, True, True, True

all = ""

if upper:
    all += uppercase_letters
if lower:
    all += lowercase_letters
if nums:
    all += digits
if symbo:
    all += symbols

length = 20
amount = 10

for x in range(amount):
    password = "".join(secrets.choice(all, length))
    print(password)